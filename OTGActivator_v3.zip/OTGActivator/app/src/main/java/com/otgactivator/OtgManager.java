package com.otgactivator;

import android.content.Context;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class OtgManager {

    private static final String TAG = "OTGActivator";
    private final Context context;

    // Known sysfs paths for OTG/USB role switching (MediaTek Helio G95 / POCO X3 GT)
    private static final String[] OTG_SYSFS_PATHS = {
        "/sys/class/usb_role/musb-hdrc/role",
        "/sys/devices/platform/musb-hdrc/mode",
        "/sys/bus/platform/devices/musb-hdrc/mode",
        "/sys/class/android_usb/android0/id_pin",
        "/sys/devices/platform/mt_usb/musb_hdrc/mode",
        "/sys/kernel/debug/usb/usb-fs/otg_enable",
        "/sys/class/extcon/extcon0/state",
        "/sys/devices/platform/mt_usb/cmode",
        "/proc/mtk_usb_dbg",
    };

    // System properties known to control OTG on MTK devices
    private static final String[] OTG_PROPS = {
        "sys.usb.otg",
        "persist.sys.usb.otg.disable",
        "persist.mtk.usb.otg",
        "ro.mtk_otg_support",
        "ro.hardware.usb",
        "ro.hardware",
    };

    public OtgManager(Context context) {
        this.context = context;
    }

    // ─────────────────────────────────────────────
    // DIAGNOSIS
    // ─────────────────────────────────────────────

    public List<DiagResult> runDiagnosis() {
        List<DiagResult> results = new ArrayList<>();

        // 1. Android USB Host API
        results.add(checkUsbHostApi());

        // 2. Kernel sysfs paths
        for (String path : OTG_SYSFS_PATHS) {
            results.add(readSysfsPath(path));
        }

        // 3. System properties
        for (String prop : OTG_PROPS) {
            results.add(readSystemProp(prop));
        }

        // 4. Kernel config OTG flag
        results.add(checkKernelConfig());

        // 5. USB devices currently connected
        results.add(checkUsbDevices());

        // 6. Root availability
        results.add(checkRoot());

        return results;
    }

    private DiagResult checkUsbHostApi() {
        UsbManager usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        if (usbManager == null) {
            return new DiagResult("USB Host API", DiagResult.Status.FAIL,
                "UsbManager não disponível neste dispositivo");
        }
        int count = usbManager.getDeviceList().size();
        return new DiagResult("USB Host API", DiagResult.Status.OK,
            "UsbManager disponível. Dispositivos conectados: " + count);
    }

    private DiagResult readSysfsPath(String path) {
        File f = new File(path);
        if (!f.exists()) {
            return new DiagResult("sysfs: " + shortenPath(path), DiagResult.Status.NOT_FOUND,
                "Caminho não existe neste kernel");
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String val = br.readLine();
            return new DiagResult("sysfs: " + shortenPath(path), DiagResult.Status.OK,
                "Valor atual: [" + (val != null ? val.trim() : "vazio") + "]");
        } catch (IOException e) {
            return new DiagResult("sysfs: " + shortenPath(path), DiagResult.Status.PERMISSION_DENIED,
                "Existe mas sem permissão de leitura (root necessário)");
        }
    }

    private DiagResult readSystemProp(String prop) {
        String val = execShell("getprop " + prop);
        if (val == null || val.trim().isEmpty()) {
            return new DiagResult("prop: " + prop, DiagResult.Status.NOT_FOUND,
                "Propriedade não definida");
        }
        return new DiagResult("prop: " + prop, DiagResult.Status.OK,
            "Valor: [" + val.trim() + "]");
    }

    private DiagResult checkKernelConfig() {
        String result = execShell("zcat /proc/config.gz 2>/dev/null | grep -i otg | head -10");
        if (result == null || result.trim().isEmpty()) {
            return new DiagResult("Kernel config OTG", DiagResult.Status.NOT_FOUND,
                "/proc/config.gz não acessível ou sem flags OTG");
        }
        return new DiagResult("Kernel config OTG", DiagResult.Status.OK,
            result.trim());
    }

    private DiagResult checkUsbDevices() {
        String result = execShell("ls /dev/bus/usb/ 2>/dev/null");
        if (result == null || result.trim().isEmpty()) {
            return new DiagResult("USB /dev/bus/usb/", DiagResult.Status.NOT_FOUND,
                "Nenhum barramento USB detectado");
        }
        return new DiagResult("USB /dev/bus/usb/", DiagResult.Status.OK,
            "Barramentos: " + result.trim().replace("\n", ", "));
    }

    private DiagResult checkRoot() {
        String result = execRoot("id");
        if (result != null && result.contains("uid=0")) {
            return new DiagResult("Root Access", DiagResult.Status.OK,
                "Root disponível! " + result.trim());
        }
        return new DiagResult("Root Access", DiagResult.Status.NOT_FOUND,
            "Root não disponível — métodos sem root serão usados");
    }

    // ─────────────────────────────────────────────
    // ACTIVATION METHODS
    // ─────────────────────────────────────────────

    public ActivationResult tryActivateMethod(ActivationMethod method) {
        switch (method) {
            case SYSFS_MUSB_HOST:
                return writeSysfs("/sys/class/usb_role/musb-hdrc/role", "host");
            case SYSFS_MUSB_OTG:
                return writeSysfs("/sys/devices/platform/musb-hdrc/mode", "otg");
            case SYSFS_CMODE:
                return writeSysfs("/sys/devices/platform/mt_usb/cmode", "1");
            case SYSFS_ANDROID_USB_HOST:
                return writeSysfs("/sys/class/android_usb/android0/id_pin", "0");
            case SETPROP_OTG:
                return setpropRoot("sys.usb.otg", "1");
            case SETPROP_PERSIST:
                return setpropRoot("persist.sys.usb.otg.disable", "0");
            case ECHO_HOST_ROLE:
                return execRootWrite("echo host > /sys/class/usb_role/musb-hdrc/role");
            case ECHO_OTG_MODE:
                return execRootWrite("echo otg > /sys/devices/platform/musb-hdrc/mode");
            case MTK_IDS_PIN:
                return execRootWrite("echo 0 > /sys/devices/platform/mt_usb/musb_hdrc/mode");
            case SERVICE_USB_HOST:
                return execRootWrite("service call usb 1 i32 1");
            case AM_BROADCAST_OTG:
                return execRootWrite(
                    "am broadcast -a android.hardware.usb.action.USB_STATE " +
                    "--ez connected true --ez host_connected true");
            default:
                return new ActivationResult(method, false, "Método desconhecido");
        }
    }

    private ActivationResult writeSysfs(String path, String value) {
        File f = new File(path);
        String methodName = "sysfs write: " + shortenPath(path) + " = " + value;
        if (!f.exists()) {
            return new ActivationResult(methodName, false,
                "Caminho não existe neste kernel");
        }
        // Try without root first
        try (FileWriter fw = new FileWriter(f)) {
            fw.write(value);
            return new ActivationResult(methodName, true,
                "Escrito sem root com sucesso");
        } catch (IOException e) {
            // Try with root
            String cmd = "echo " + value + " > " + path;
            String res = execRoot(cmd);
            if (res != null && !res.toLowerCase().contains("error")) {
                // Verify
                String verify = execRoot("cat " + path);
                if (verify != null && verify.trim().equals(value)) {
                    return new ActivationResult(methodName, true,
                        "Escrito via root. Verificado: [" + verify.trim() + "]");
                }
                return new ActivationResult(methodName, true,
                    "Comando root executado (verificação não confirmada)");
            }
            return new ActivationResult(methodName, false,
                "Falha mesmo com root: " + (res != null ? res.trim() : "sem resposta"));
        }
    }

    private ActivationResult setpropRoot(String prop, String value) {
        String methodName = "setprop: " + prop + " = " + value;
        String res = execRoot("setprop " + prop + " " + value);
        String verify = execShell("getprop " + prop);
        if (verify != null && verify.trim().equals(value)) {
            return new ActivationResult(methodName, true,
                "Propriedade definida e verificada");
        }
        return new ActivationResult(methodName, false,
            "Falha ao definir propriedade. Root response: " + (res != null ? res.trim() : "nenhum"));
    }

    private ActivationResult execRootWrite(String cmd) {
        String methodName = "cmd: " + cmd.substring(0, Math.min(cmd.length(), 40)) + "...";
        String res = execRoot(cmd);
        boolean success = res != null && !res.toLowerCase().contains("error")
                       && !res.toLowerCase().contains("permission denied")
                       && !res.toLowerCase().contains("not found");
        return new ActivationResult(methodName, success,
            res != null ? res.trim() : "Sem resposta do shell");
    }

    // ─────────────────────────────────────────────
    // SHELL HELPERS
    // ─────────────────────────────────────────────

    public String execShell(String cmd) {
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            process.waitFor();
            return sb.toString();
        } catch (Exception e) {
            Log.e(TAG, "execShell error: " + e.getMessage());
            return null;
        }
    }

    public String execRoot(String cmd) {
        try {
            Process su = Runtime.getRuntime().exec("su");
            su.getOutputStream().write((cmd + "\n").getBytes());
            su.getOutputStream().write("exit\n".getBytes());
            su.getOutputStream().flush();

            BufferedReader reader = new BufferedReader(
                new InputStreamReader(su.getInputStream()));
            BufferedReader errReader = new BufferedReader(
                new InputStreamReader(su.getErrorStream()));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append("\n");
            while ((line = errReader.readLine()) != null) sb.append("[err] ").append(line).append("\n");

            su.waitFor();
            return sb.toString().trim().isEmpty() ? "OK" : sb.toString();
        } catch (Exception e) {
            Log.e(TAG, "execRoot error: " + e.getMessage());
            return null;
        }
    }

    private String shortenPath(String path) {
        String[] parts = path.split("/");
        return parts.length > 2 ? ".../" + parts[parts.length - 2] + "/" + parts[parts.length - 1] : path;
    }

    // ─────────────────────────────────────────────
    // DATA CLASSES
    // ─────────────────────────────────────────────

    public static class DiagResult {
        public enum Status { OK, FAIL, NOT_FOUND, PERMISSION_DENIED }
        public final String label;
        public final Status status;
        public final String detail;

        public DiagResult(String label, Status status, String detail) {
            this.label = label;
            this.status = status;
            this.detail = detail;
        }
    }

    public static class ActivationResult {
        public final String method;
        public final boolean success;
        public final String detail;

        public ActivationResult(String method, boolean success, String detail) {
            this.method = method;
            this.success = success;
            this.detail = detail;
        }

        public ActivationResult(ActivationMethod method, boolean success, String detail) {
            this.method = method.name();
            this.success = success;
            this.detail = detail;
        }
    }

    public enum ActivationMethod {
        SYSFS_MUSB_HOST,
        SYSFS_MUSB_OTG,
        SYSFS_CMODE,
        SYSFS_ANDROID_USB_HOST,
        SETPROP_OTG,
        SETPROP_PERSIST,
        ECHO_HOST_ROLE,
        ECHO_OTG_MODE,
        MTK_IDS_PIN,
        SERVICE_USB_HOST,
        AM_BROADCAST_OTG
    }
}
