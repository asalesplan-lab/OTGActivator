package com.otgactivator;

import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.List;

import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private OtgManager otgManager;
    private LinearLayout diagContainer, shizukuDiagContainer;
    private LinearLayout activateContainer, shizukuActivateContainer;
    private TextView statusTitle, shizukuStatusText;
    private MaterialButton btnDiag, btnActivate;
    private MaterialButton btnShizukuPerm, btnShizukuDiag, btnShizukuActivate;
    private LinearProgressIndicator progressBar;
    private ScrollView scrollView;

    private final Shizuku.OnRequestPermissionResultListener permListener =
        (requestCode, grantResult) -> {
            if (requestCode == ShizukuManager.REQUEST_CODE)
                runOnUiThread(this::updateShizukuStatus);
        };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        otgManager = new OtgManager(this);

        diagContainer         = findViewById(R.id.diagContainer);
        shizukuDiagContainer  = findViewById(R.id.shizukuDiagContainer);
        activateContainer     = findViewById(R.id.activateContainer);
        shizukuActivateContainer = findViewById(R.id.shizukuActivateContainer);
        statusTitle           = findViewById(R.id.statusTitle);
        shizukuStatusText     = findViewById(R.id.shizukuStatusText);
        btnDiag               = findViewById(R.id.btnDiag);
        btnActivate           = findViewById(R.id.btnActivate);
        btnShizukuPerm        = findViewById(R.id.btnShizukuPerm);
        btnShizukuDiag        = findViewById(R.id.btnShizukuDiag);
        btnShizukuActivate    = findViewById(R.id.btnShizukuActivate);
        progressBar           = findViewById(R.id.progressBar);
        scrollView            = findViewById(R.id.scrollView);

        btnDiag.setOnClickListener(v -> runDiagnosis());
        btnActivate.setOnClickListener(v -> runAllActivations());
        btnShizukuPerm.setOnClickListener(v -> { ShizukuManager.requestPermission(); });
        btnShizukuDiag.setOnClickListener(v -> runShizukuDiagnosis());
        btnShizukuActivate.setOnClickListener(v -> runShizukuActivations());

        Shizuku.addRequestPermissionResultListener(permListener);
        updateShizukuStatus();
    }

    @Override protected void onResume() { super.onResume(); updateShizukuStatus(); }
    @Override protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(permListener);
    }

    private void updateShizukuStatus() {
        String status = ShizukuManager.getStatus();
        shizukuStatusText.setText(status);
        boolean running = ShizukuManager.isRunning();
        boolean hasPerm = ShizukuManager.hasPermission();

        if (running && hasPerm) {
            shizukuStatusText.setTextColor(Color.parseColor("#00C853"));
            btnShizukuPerm.setVisibility(View.GONE);
        } else if (running) {
            shizukuStatusText.setTextColor(Color.parseColor("#FF9800"));
            btnShizukuPerm.setVisibility(View.VISIBLE);
        } else {
            shizukuStatusText.setTextColor(Color.parseColor("#FF5252"));
            btnShizukuPerm.setVisibility(View.GONE);
        }
        btnShizukuDiag.setEnabled(running && hasPerm);
        btnShizukuActivate.setEnabled(running && hasPerm);
    }

    // ── DIAGNÓSTICO SEM ROOT ──
    private void runDiagnosis() {
        setUiBusy(true, "Executando diagnóstico...");
        diagContainer.removeAllViews();
        new AsyncTask<Void, OtgManager.DiagResult, Void>() {
            protected Void doInBackground(Void... v) {
                for (OtgManager.DiagResult r : otgManager.runDiagnosis()) publishProgress(r);
                return null;
            }
            protected void onProgressUpdate(OtgManager.DiagResult... vals) {
                addDiagCard(diagContainer, vals[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }
            protected void onPostExecute(Void v) {
                setUiBusy(false, ""); statusTitle.setText("✓ Diagnóstico completo");
            }
        }.execute();
    }

    // ── ATIVAÇÃO SEM ROOT ──
    private void runAllActivations() {
        setUiBusy(true, "Tentando ativar OTG...");
        activateContainer.removeAllViews();
        new AsyncTask<Void, OtgManager.ActivationResult, Integer>() {
            protected Integer doInBackground(Void... v) {
                int ok = 0;
                for (OtgManager.ActivationMethod m : OtgManager.ActivationMethod.values()) {
                    OtgManager.ActivationResult r = otgManager.tryActivateMethod(m);
                    if (r.success) ok++;
                    publishProgress(r);
                    try { Thread.sleep(200); } catch (InterruptedException ignored) {}
                }
                return ok;
            }
            protected void onProgressUpdate(OtgManager.ActivationResult... vals) {
                addActivationCard(activateContainer, vals[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }
            protected void onPostExecute(Integer ok) {
                setUiBusy(false, "");
                statusTitle.setText(ok > 0 ? "✓ " + ok + " método(s) sem root aplicado(s)!" : "⚠ Sem root: nenhum método confirmado");
                statusTitle.setTextColor(Color.parseColor(ok > 0 ? "#00C853" : "#FF9800"));
            }
        }.execute();
    }

    // ── DIAGNÓSTICO SHIZUKU ──
    private void runShizukuDiagnosis() {
        setUiBusy(true, "Diagnóstico via Shizuku...");
        shizukuDiagContainer.removeAllViews();
        new AsyncTask<Void, OtgManager.DiagResult, Void>() {
            protected Void doInBackground(Void... v) {
                for (OtgManager.DiagResult r : ShizukuManager.runShizukuDiagnosis()) publishProgress(r);
                return null;
            }
            protected void onProgressUpdate(OtgManager.DiagResult... vals) {
                addDiagCard(shizukuDiagContainer, vals[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }
            protected void onPostExecute(Void v) { setUiBusy(false, "Diagnóstico Shizuku concluído"); }
        }.execute();
    }

    // ── ATIVAÇÃO SHIZUKU ──
    private void runShizukuActivations() {
        setUiBusy(true, "Tentando ativar OTG via Shizuku...");
        shizukuActivateContainer.removeAllViews();
        new AsyncTask<Void, OtgManager.ActivationResult, Integer>() {
            protected Integer doInBackground(Void... v) {
                int ok = 0;
                for (OtgManager.ActivationResult r : ShizukuManager.tryAllMethods()) {
                    if (r.success) ok++;
                    publishProgress(r);
                    try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                }
                return ok;
            }
            protected void onProgressUpdate(OtgManager.ActivationResult... vals) {
                addActivationCard(shizukuActivateContainer, vals[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }
            protected void onPostExecute(Integer ok) {
                setUiBusy(false, "");
                statusTitle.setText(ok > 0 ? "✓ Shizuku: " + ok + " método(s) aplicado(s)! Conecte o cabo OTG." : "⚠ Shizuku: kernel pode estar bloqueando.");
                statusTitle.setTextColor(Color.parseColor(ok > 0 ? "#00C853" : "#FF5252"));
            }
        }.execute();
    }

    // ── UI HELPERS ──
    private void addDiagCard(LinearLayout c, OtgManager.DiagResult r) {
        CardView card = buildCard();
        LinearLayout inner = (LinearLayout) card.getChildAt(0);
        String color; String icon;
        switch (r.status) {
            case OK: color = "#00C853"; icon = "● "; break;
            case FAIL: color = "#FF5252"; icon = "✗ "; break;
            case PERMISSION_DENIED: color = "#FF9800"; icon = "⚠ "; break;
            default: color = "#546E7A"; icon = "— "; break;
        }
        TextView lbl = new TextView(this);
        lbl.setText(icon + r.label); lbl.setTextSize(13f); lbl.setTextColor(Color.parseColor(color));
        TextView det = new TextView(this);
        det.setText(r.detail); det.setTextSize(12f); det.setTextColor(Color.parseColor("#CCCCCC")); det.setPadding(0, 4, 0, 0);
        inner.addView(lbl); inner.addView(det); c.addView(card);
    }

    private void addActivationCard(LinearLayout c, OtgManager.ActivationResult r) {
        CardView card = buildCard();
        LinearLayout inner = (LinearLayout) card.getChildAt(0);
        TextView lbl = new TextView(this);
        lbl.setText(r.success ? "✓ " + r.method : "✗ " + r.method);
        lbl.setTextSize(13f); lbl.setTextColor(Color.parseColor(r.success ? "#00C853" : "#546E7A"));
        TextView det = new TextView(this);
        det.setText(r.detail); det.setTextSize(12f); det.setTextColor(Color.parseColor("#CCCCCC")); det.setPadding(0, 4, 0, 0);
        inner.addView(lbl); inner.addView(det); c.addView(card);
    }

    private CardView buildCard() {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, dpToPx(8));
        card.setLayoutParams(p);
        card.setCardBackgroundColor(Color.parseColor("#1E2530"));
        card.setRadius(dpToPx(8)); card.setCardElevation(dpToPx(2));
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));
        card.addView(inner);
        return card;
    }

    private void setUiBusy(boolean busy, String msg) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnDiag.setEnabled(!busy); btnActivate.setEnabled(!busy);
        boolean ready = ShizukuManager.isRunning() && ShizukuManager.hasPermission();
        btnShizukuDiag.setEnabled(!busy && ready); btnShizukuActivate.setEnabled(!busy && ready);
        if (busy && !msg.isEmpty()) { statusTitle.setText(msg); statusTitle.setTextColor(Color.parseColor("#90A4AE")); }
    }

    private int dpToPx(int dp) { return (int)(dp * getResources().getDisplayMetrics().density); }
}
