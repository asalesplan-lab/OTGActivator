# OTG Activator — POCO X3 GT

Aplicativo de diagnóstico e ativação de OTG para POCO X3 GT (MediaTek Helio G95 / Android 13).

---

## ▶ Como compilar

### Pré-requisitos
- Android Studio Hedgehog ou superior
- JDK 11+
- Android SDK (API 34)

### Passos

```bash
# 1. Abra o projeto no Android Studio
#    File > Open > selecione a pasta OTGActivator

# 2. Deixe o Gradle sincronizar

# 3. Compile via terminal (na raiz do projeto):
./gradlew assembleDebug

# 4. APK gerado em:
app/build/outputs/apk/debug/app-debug.apk

# 5. Instale via ADB:
adb install app/build/outputs/apk/debug/app-debug.apk
```

No Windows use `gradlew.bat assembleDebug` em vez de `./gradlew`.

---

## 🔍 O que o app faz

### Diagnóstico
Verifica e exibe o valor atual de:
- USB Host API do Android
- Caminhos sysfs do kernel MTK (`/sys/class/usb_role/`, `/sys/devices/platform/musb-hdrc/`, etc.)
- Propriedades do sistema (`getprop`) relacionadas a OTG
- Configurações do kernel (`/proc/config.gz`)
- Dispositivos USB conectados (`/dev/bus/usb/`)
- Disponibilidade de root

### Tentativas de ativação (11 métodos)
| Método | Descrição |
|--------|-----------|
| SYSFS_MUSB_HOST | Escreve `host` em `/sys/class/usb_role/musb-hdrc/role` |
| SYSFS_MUSB_OTG | Escreve `otg` em `/sys/devices/platform/musb-hdrc/mode` |
| SYSFS_CMODE | Ativa cmode MTK |
| SYSFS_ANDROID_USB_HOST | Define id_pin = 0 (modo host) |
| SETPROP_OTG | `setprop sys.usb.otg 1` via root |
| SETPROP_PERSIST | `setprop persist.sys.usb.otg.disable 0` via root |
| ECHO_HOST_ROLE | echo via root no sysfs |
| ECHO_OTG_MODE | echo mode otg via root |
| MTK_IDS_PIN | Controle de ID pin MTK |
| SERVICE_USB_HOST | `service call usb` |
| AM_BROADCAST_OTG | Broadcast USB host state |

---

## ⚠ Observações
- Métodos sem root tentam escrita direta no sysfs (funciona em alguns builds)
- Métodos com root requerem Magisk ou similar
- O app não persiste as mudanças entre reinicializações (use scripts init.d para isso)
- Testado para Android 13 / MIUI 14 / HyperOS

---

## 📁 Estrutura do projeto
```
OTGActivator/
├── app/
│   ├── src/main/
│   │   ├── java/com/otgactivator/
│   │   │   ├── MainActivity.java    ← UI principal
│   │   │   └── OtgManager.java      ← Lógica de diagnóstico e ativação
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml
│   │   │   └── values/{themes, colors, strings}.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```
