package com.otgactivator;

import android.content.pm.PackageManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;

public class ShizukuManager {

    private static final String TAG = "ShizukuManager";
    public static final int REQUEST_CODE = 100;

    // ─────────────────────────────────────────────
    // STATUS
    // ─────────────────────────────────────────────

    public static boolean isRunning() {
        try {
            return Shizuku.getBinder() != null && Shizuku.getBinder().isBinderAlive();
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasPermission() {
        try {
            if (Shizuku.isPreV11()) return false;
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getStatus() {
        try {
            if (!isRunning()) return "❌ Shizuku não está rodando";
            if (!hasPermission()) return "⚠ Shizuku ativo — permissão pendente";
            return "✓ Shizuku ativo e autorizado";
        } catch (Exception e) {
            return "❌ Shizuku não instalado ou inativo";
        }
    }

    public static void requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE);
        } catch (Exception e) {
            Log.e(TAG, "requestPermission: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────
    // EXECUÇÃO PRIVILEGIADA
    // ─────────────────────────────────────────────

    public static String exec(String cmd) {
        if (!isRunning()) return "[ERRO] Shizuku não está rodando";
        if (!hasPermission()) return "[ERRO] Permissão não concedida";

        try {
            Process process = Shizuku.newProcess(
                new String[]{"sh", "-c", cmd}, null, null);

            BufferedReader out = new BufferedReader(
                new InputStreamReader(process.getInputStream()));
            BufferedReader err = new BufferedReader(
                new InputStreamReader(process.getErrorStream()));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = out.readLine()) != null) sb.append(line).append("\n");
            while ((line = err.readLine()) != null) sb.append("[err] ").append(line).append("\n");
            process.waitFor();

            String result = sb.toString().trim();
            return result.isEmpty() ? "OK" : result;

        } catch (Exception e) {
            Log.e(TAG, "exec error: " + e.getMessage());
            return "[ERRO] " + e.getMessage();
        }
    }

    // ─────────────────────────────────────────────
    // DIAGNÓSTICO VIA SHIZUKU
    // ─────────────────────────────────────────────

    public static List<OtgManager.DiagResult> runShizukuDiagnosis() {
        List<OtgManager.DiagResult> results = new ArrayList<>();

        // dumpsys usb
        String usb = exec("dumpsys usb 2>/dev/null | head -60");
        results.add(new OtgManager.DiagResult(
            "dumpsys usb",
            usb.startsWith("[ERRO]") ? OtgManager.DiagResult.Status.FAIL : OtgManager.DiagResult.Status.OK,
            usb.length() > 200 ? usb.substring(0, 200) + "..." : usb
        ));

        // settings get global usb_otg_enabled
        String otgFlag = exec("settings get global usb_otg_enabled");
        results.add(new OtgManager.DiagResult(
            "global: usb_otg_enabled",
            otgFlag.contains("1") ? OtgManager.DiagResult.Status.OK : OtgManager.DiagResult.Status.NOT_FOUND,
            "Valor atual: [" + otgFlag.trim() + "]"
        ));

        // sys.usb.config
        String usbConfig = exec("getprop sys.usb.config");
        results.add(new OtgManager.DiagResult(
            "prop: sys.usb.config",
            !usbConfig.startsWith("[ERRO]") && !usbConfig.trim().isEmpty()
                ? OtgManager.DiagResult.Status.OK : OtgManager.DiagResult.Status.NOT_FOUND,
            "Valor: [" + usbConfig.trim() + "]"
        ));

        // sys.usb.state
        String usbState = exec("getprop sys.usb.state");
        results.add(new OtgManager.DiagResult(
            "prop: sys.usb.state",
            !usbState.startsWith("[ERRO]") && !usbState.trim().isEmpty()
                ? OtgManager.DiagResult.Status.OK : OtgManager.DiagResult.Status.NOT_FOUND,
            "Valor: [" + usbState.trim() + "]"
        ));

        // /dev/bus/usb
        String devUsb = exec("ls /dev/bus/usb/ 2>/dev/null");
        results.add(new OtgManager.DiagResult(
            "USB /dev/bus/usb/",
            !devUsb.trim().isEmpty() && !devUsb.startsWith("[ERRO]")
                ? OtgManager.DiagResult.Status.OK : OtgManager.DiagResult.Status.NOT_FOUND,
            devUsb.trim().isEmpty() ? "Nenhum barramento detectado" : devUsb.trim()
        ));

        // id do processo (confirma que é shell privilegiado)
        String id = exec("id");
        results.add(new OtgManager.DiagResult(
            "shell uid (Shizuku)",
            id.contains("uid=2000") || id.contains("shell")
                ? OtgManager.DiagResult.Status.OK : OtgManager.DiagResult.Status.FAIL,
            id.trim()
        ));

        return results;
    }

    // ─────────────────────────────────────────────
    // MÉTODOS DE ATIVAÇÃO VIA SHIZUKU
    // ─────────────────────────────────────────────

    public static List<OtgManager.ActivationResult> tryAllMethods() {
        List<OtgManager.ActivationResult> results = new ArrayList<>();

        results.add(tryMethod(
            "settings: usb_otg_enabled = 1",
            "settings put global usb_otg_enabled 1",
            "settings get global usb_otg_enabled",
            "1"
        ));

        results.add(tryMethod(
            "svc usb setFunctions host",
            "svc usb setFunctions host",
            null, null
        ));

        results.add(tryMethod(
            "setprop sys.usb.config host",
            "setprop sys.usb.config host",
            "getprop sys.usb.config",
            "host"
        ));

        results.add(tryMethod(
            "setprop sys.usb.state host",
            "setprop sys.usb.state host",
            "getprop sys.usb.state",
            "host"
        ));

        results.add(tryMethod(
            "setprop persist.sys.usb.config host",
            "setprop persist.sys.usb.config host",
            "getprop persist.sys.usb.config",
            "host"
        ));

        results.add(tryMethod(
            "svc usb setFunctions mtp,host",
            "svc usb setFunctions mtp,host",
            null, null
        ));

        results.add(tryMethod(
            "am broadcast USB_STATE host",
            "am broadcast -a android.hardware.usb.action.USB_STATE " +
            "--ez connected true --ez host_connected true",
            null, null
        ));

        results.add(tryMethod(
            "settings: adb_enabled = 1",
            "settings put global adb_enabled 1",
            "settings get global adb_enabled",
            "1"
        ));

        // MTK específico
        results.add(tryMethod(
            "setprop mtk.usb.host 1",
            "setprop mtk.usb.host 1",
            "getprop mtk.usb.host",
            "1"
        ));

        results.add(tryMethod(
            "setprop sys.usb.mtk_otg_enable 1",
            "setprop sys.usb.mtk_otg_enable 1",
            "getprop sys.usb.mtk_otg_enable",
            "1"
        ));

        return results;
    }

    private static OtgManager.ActivationResult tryMethod(
            String name, String cmd, String verifyCmd, String expectedVal) {
        String result = exec(cmd);
        boolean success = !result.startsWith("[ERRO]")
                       && !result.toLowerCase().contains("permission denied")
                       && !result.toLowerCase().contains("not found");

        if (success && verifyCmd != null && expectedVal != null) {
            String verify = exec(verifyCmd);
            success = verify.trim().equals(expectedVal);
            return new OtgManager.ActivationResult(name, success,
                success ? "Aplicado e verificado ✓" : "Executado, mas verificação falhou: [" + verify.trim() + "]");
        }

        return new OtgManager.ActivationResult(name, success,
            success ? "Executado sem erros" : result.trim());
    }
}
