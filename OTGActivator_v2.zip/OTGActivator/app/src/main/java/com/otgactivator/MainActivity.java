package com.otgactivator;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private OtgManager otgManager;
    private LinearLayout diagContainer;
    private LinearLayout activateContainer;
    private LinearLayout logContainer;
    private TextView statusTitle;
    private MaterialButton btnDiag;
    private MaterialButton btnActivate;
    private LinearProgressIndicator progressBar;
    private ScrollView scrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        otgManager = new OtgManager(this);

        diagContainer = findViewById(R.id.diagContainer);
        activateContainer = findViewById(R.id.activateContainer);
        logContainer = findViewById(R.id.logContainer);
        statusTitle = findViewById(R.id.statusTitle);
        btnDiag = findViewById(R.id.btnDiag);
        btnActivate = findViewById(R.id.btnActivate);
        progressBar = findViewById(R.id.progressBar);
        scrollView = findViewById(R.id.scrollView);

        btnDiag.setOnClickListener(v -> runDiagnosis());
        btnActivate.setOnClickListener(v -> runAllActivations());
    }

    // ─────────────────────────────────────────────
    // DIAGNOSIS
    // ─────────────────────────────────────────────

    private void runDiagnosis() {
        setUiBusy(true, "Executando diagnóstico...");
        diagContainer.removeAllViews();
        activateContainer.removeAllViews();

        new AsyncTask<Void, OtgManager.DiagResult, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                List<OtgManager.DiagResult> results = otgManager.runDiagnosis();
                for (OtgManager.DiagResult r : results) {
                    publishProgress(r);
                }
                return null;
            }

            @Override
            protected void onProgressUpdate(OtgManager.DiagResult... values) {
                addDiagCard(values[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                setUiBusy(false, "Diagnóstico concluído");
                statusTitle.setText("✓ Diagnóstico completo");
            }
        }.execute();
    }

    // ─────────────────────────────────────────────
    // ACTIVATION
    // ─────────────────────────────────────────────

    private void runAllActivations() {
        setUiBusy(true, "Tentando ativar OTG...");
        activateContainer.removeAllViews();

        OtgManager.ActivationMethod[] methods = OtgManager.ActivationMethod.values();

        new AsyncTask<Void, OtgManager.ActivationResult, Integer>() {
            @Override
            protected Integer doInBackground(Void... voids) {
                int successes = 0;
                for (OtgManager.ActivationMethod m : methods) {
                    OtgManager.ActivationResult r = otgManager.tryActivateMethod(m);
                    if (r.success) successes++;
                    publishProgress(r);
                    try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                }
                return successes;
            }

            @Override
            protected void onProgressUpdate(OtgManager.ActivationResult... values) {
                addActivationCard(values[0]);
                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }

            @Override
            protected void onPostExecute(Integer successes) {
                setUiBusy(false, "Ativação concluída");
                if (successes > 0) {
                    statusTitle.setText("✓ " + successes + " método(s) aplicado(s)! Conecte o cabo OTG.");
                    statusTitle.setTextColor(Color.parseColor("#00C853"));
                } else {
                    statusTitle.setText("⚠ Nenhum método teve efeito confirmado. Root pode ser necessário.");
                    statusTitle.setTextColor(Color.parseColor("#FF6D00"));
                }
            }
        }.execute();
    }

    // ─────────────────────────────────────────────
    // UI HELPERS
    // ─────────────────────────────────────────────

    private void addDiagCard(OtgManager.DiagResult result) {
        CardView card = buildCard();
        LinearLayout inner = (LinearLayout) card.getChildAt(0);

        TextView label = new TextView(this);
        label.setText(result.label);
        label.setTextSize(13f);
        label.setTextColor(Color.parseColor("#BBBBBB"));

        TextView detail = new TextView(this);
        detail.setText(result.detail);
        detail.setTextSize(12f);
        detail.setPadding(0, 4, 0, 0);

        String colorHex;
        String icon;
        switch (result.status) {
            case OK:
                colorHex = "#00C853"; icon = "● "; break;
            case FAIL:
                colorHex = "#FF1744"; icon = "✗ "; break;
            case PERMISSION_DENIED:
                colorHex = "#FF6D00"; icon = "⚠ "; break;
            default:
                colorHex = "#546E7A"; icon = "— "; break;
        }
        label.setText(icon + result.label);
        label.setTextColor(Color.parseColor(colorHex));
        detail.setTextColor(Color.parseColor("#CCCCCC"));

        inner.addView(label);
        inner.addView(detail);
        diagContainer.addView(card);
    }

    private void addActivationCard(OtgManager.ActivationResult result) {
        CardView card = buildCard();
        LinearLayout inner = (LinearLayout) card.getChildAt(0);

        TextView label = new TextView(this);
        TextView detail = new TextView(this);

        label.setTextSize(13f);
        detail.setTextSize(12f);
        detail.setPadding(0, 4, 0, 0);
        detail.setTextColor(Color.parseColor("#CCCCCC"));

        if (result.success) {
            label.setText("✓ " + result.method);
            label.setTextColor(Color.parseColor("#00C853"));
        } else {
            label.setText("✗ " + result.method);
            label.setTextColor(Color.parseColor("#546E7A"));
        }
        detail.setText(result.detail);

        inner.addView(label);
        inner.addView(detail);
        activateContainer.addView(card);
    }

    private CardView buildCard() {
        CardView card = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, dpToPx(8));
        card.setLayoutParams(cardParams);
        card.setCardBackgroundColor(Color.parseColor("#1E2530"));
        card.setRadius(dpToPx(8));
        card.setCardElevation(dpToPx(2));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10));
        card.addView(inner);
        return card;
    }

    private void setUiBusy(boolean busy, String msg) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnDiag.setEnabled(!busy);
        btnActivate.setEnabled(!busy);
        if (busy) {
            statusTitle.setText(msg);
            statusTitle.setTextColor(Color.parseColor("#90A4AE"));
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
